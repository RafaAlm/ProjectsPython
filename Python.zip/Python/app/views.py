from django.shortcuts import render, redirect
from app.forms import CarrosForms, ClienteForms
from app.models import Carros, Cliente
from django.core.paginator import Paginator

# Create your views here.
def home(request):
    data = {}

    search = request.GET.get('search')
    if search:
        data['db'] = Carros.objects.filter(modelo__icontains=search)
    else:
        data['db'] = Carros.objects.all()

    #all = Carros.objects.all()
    #paginator = Paginator(all, 2)
    #pages = request.GET.get('page')
    #data['db'] = paginator.get_page(pages)
    return render(request, 'index.html',data)

def form(request):
    data = { }
    data['form'] = CarrosForms()
    return render(request, 'form.html', data)

def form2(request):
    data = { }
    data['form'] = ClienteForms()
    return render(request, 'form2.html', data)




def create(request):
    form = CarrosForms(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')

def createcliente(request):
    form = ClienteForms(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')

def view(request, pk):
    data = { }
    data['db'] = Carros.objects.get(pk=pk)

    data1 = {}
    data1['db'] = Cliente.objects.get(pk=pk)

    return render(request, 'view.html',data,data1)


def edit(request, pk):
    data = { }
    data['db'] = Carros.objects.get(pk=pk)
    data['form'] = CarrosForms(instance=data['db'])
    return render(request,'form.html', data)

def update(request, pk):
    data = { }
    data['db'] = Carros.objects.get(pk=pk)
    form = CarrosForms(request.POST or None, instance=data['db'])
    if form.is_valid():
        form.save()
        return redirect('home')

def delete(request, pk):
    db = Carros.objects.get(pk=pk)
    db.delete()
    return redirect('home')
















