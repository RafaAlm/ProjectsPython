from django.forms import ModelForm
from app.models import Carros, Cliente

# Create the form class.
class CarrosForms(ModelForm):
    class Meta:
        model = Carros
        fields = ['modelo', 'marca', 'ano']

class ClienteForms(ModelForm):
    class Meta:
        model = Cliente
        fields = ['nome', 'cpf', 'telefone']
